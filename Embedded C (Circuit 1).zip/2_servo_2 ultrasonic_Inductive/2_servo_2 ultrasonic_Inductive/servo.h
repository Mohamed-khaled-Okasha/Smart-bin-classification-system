#ifndef SERVO_H
#define SERVO_H

#include <avr/io.h>
#include <util/delay.h>

// Servo Pins
#define SERVO_PIN PD5        // SG90 Servo connected to PD5
#define SERVO2_PIN PD3       // MG995 Full Metal Servo connected to PD3

// Movement time constants for MG995 Full Metal continuous rotation servo
#define OPEN_TIME_MS 1000    // Time to open the trash bin (adjust as needed)
#define CLOSE_TIME_MS 1000   // Time to close the trash bin (adjust as needed)

// Standard SG90 Servo functions
void servo_right(void);
void servo_left(void);
void servo_center(void);

// MG995 Full Metal continuous rotation servo functions
void servo2_stop(void);
void servo2_open_trash(void);
void servo2_close_trash(void);

// Initialization function
void servo_init(void);

#endif /* SERVO_H */