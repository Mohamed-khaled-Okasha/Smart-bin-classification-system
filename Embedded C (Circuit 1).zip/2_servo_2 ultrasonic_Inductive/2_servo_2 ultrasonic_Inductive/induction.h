#ifndef INDUCTION_H
#define INDUCTION_H

#include <avr/io.h>

// Induction Sensor Pin
#define METAL_SENSOR_PIN PD2 // Inductive Proximity Sensor connected to PD2

// Function to check if metal is detected
uint8_t is_metal_detected(void);

// Initialize the induction sensor
void induction_init(void);

#endif /* INDUCTION_H */