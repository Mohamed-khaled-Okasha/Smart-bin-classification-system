#include "ultrasonic.h"

// Initialize ultrasonic sensor pins
void ultrasonic_init(void) {
    // Set primary ultrasonic sensor pins
    DDRD |= (1 << TRIG_PIN);    // TRIG as output
    DDRD &= ~(1 << ECHO_PIN);   // ECHO as input
    
    // Set secondary ultrasonic sensor pins
    DDRC |= (1 << TRIG2_PIN);   // TRIG2 as output
    DDRC &= ~(1 << ECHO2_PIN);  // ECHO2 as input
}

// Function to measure the distance using the primary ultrasonic sensor
uint16_t measure_distance(void) {
    // Send a pulse to trigger the ultrasonic sensor
    PORTD |= (1 << TRIG_PIN);     // TRIG high
    _delay_us(10);                // Wait for 10us
    PORTD &= ~(1 << TRIG_PIN);    // TRIG low

    // Wait for ECHO to go high
    while (!(PIND & (1 << ECHO_PIN))) {}

    // Start the timer for ECHO high pulse
    uint16_t start_time = 0;
    while (PIND & (1 << ECHO_PIN)) {
        start_time++;   // Increment counter while ECHO is high
        _delay_us(1);   // Delay 1 microsecond for accurate time
    }
    
    // Calculate distance in centimeters (speed of sound = 343 m/s or 0.0343 cm/us)
    uint16_t distance = start_time * 0.0343 / 2;   // Divide by 2 for round trip

    return distance;  // Return the distance in centimeters
}

// Function to measure distance using the secondary ultrasonic sensor
uint16_t measure_distance2(void) {
    // Send pulse
    PORTC |= (1 << TRIG2_PIN);
    _delay_us(10);
    PORTC &= ~(1 << TRIG2_PIN);

    // Wait for echo high
    while (!(PINC & (1 << ECHO2_PIN))) {}

    uint16_t duration = 0;
    while (PINC & (1 << ECHO2_PIN)) {
        duration++;
        _delay_us(1);
    }

    uint16_t distance = duration * 0.0343 / 2;
    return distance;
}