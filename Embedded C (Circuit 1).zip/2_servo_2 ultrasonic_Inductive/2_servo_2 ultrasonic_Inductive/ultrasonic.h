#ifndef ULTRASONIC_H
#define ULTRASONIC_H

#include <avr/io.h>
#include <util/delay.h>

// Primary Ultrasonic Sensor Pins
#define TRIG_PIN PD6   // TRIG connected to PD6 - sends trigger pulses
#define ECHO_PIN PD0   // ECHO connected to PD0 - reads echo signals

// Secondary Ultrasonic Sensor Pins
#define TRIG2_PIN PC0  // TRIG2 connected to PC0 (A0)
#define ECHO2_PIN PC1  // ECHO2 connected to PC1 (A1)

// Function to measure distance with primary ultrasonic sensor
uint16_t measure_distance(void);

// Function to measure distance with secondary ultrasonic sensor
uint16_t measure_distance2(void);

// Initialize ultrasonic sensor pins
void ultrasonic_init(void);

#endif /* ULTRASONIC_H */