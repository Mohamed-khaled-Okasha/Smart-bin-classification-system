#ifndef CONFIG_H
#define CONFIG_H

// CPU frequency
#define F_CPU 16000000UL

// Distance thresholds
#define SORTING_DISTANCE_THRESHOLD 3  // Distance threshold for sorting objects (cm)
#define TRASH_OPEN_DISTANCE_THRESHOLD 5  // Distance threshold for opening trash bin (cm)

#endif /* CONFIG_H */