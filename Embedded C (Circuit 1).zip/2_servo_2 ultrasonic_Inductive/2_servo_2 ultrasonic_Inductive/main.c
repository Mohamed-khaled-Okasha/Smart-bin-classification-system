#include <avr/io.h>
#include <util/delay.h>

#define F_CPU 16000000UL

#include "servo.h"
#include "ultrasonic.h"
#include "induction.h"

int main(void) {
    // Initialize all components
    servo_init();
    ultrasonic_init();
    induction_init();
    
    // Variable to track if trash bin is open
    uint8_t trash_is_open = 0;

    while (1) {
        // ---------- First part: First servo (SG90) ----------
        uint16_t distance1 = measure_distance();  // From first ultrasonic

        if (distance1 < 3) {
            if (is_metal_detected()) {
                servo_right();
                _delay_ms(500);
                servo_center();
            } else {
                servo_left();
                _delay_ms(500);
                servo_center();
            }
            _delay_ms(500);  // Small delay before re-measuring
        }

        // ---------- Second part: Second servo (MG995 Full Metal) ----------
        uint16_t distance2 = measure_distance2();  // From second ultrasonic

        if (distance2 < 5) {
            if (!trash_is_open) {
                servo2_open_trash();
                trash_is_open = 1;
            }
        } else {
            if (trash_is_open) {
                servo2_close_trash();
                trash_is_open = 0;
            }
        }
        
        _delay_ms(100);  // Small delay before next check
    }

    return 0;
}