#include "induction.h"

// Initialize the induction sensor
void induction_init(void) {
    // Set Inductive Proximity Sensor pin as input
    DDRD &= ~(1 << METAL_SENSOR_PIN);
    
    // Enable pull-up resistor on the sensor pin
    PORTD |= (1 << METAL_SENSOR_PIN);
}

// Function to check if metal is detected
uint8_t is_metal_detected(void) {
    // Returns 1 if metal is detected, 0 otherwise
    // Note: Check your sensor's behavior - some sensors output LOW when metal is detected,
    // while others output HIGH.
    // Current implementation assumes the sensor outputs HIGH when metal is detected
    return (PIND & (1 << METAL_SENSOR_PIN)) != 0;
}