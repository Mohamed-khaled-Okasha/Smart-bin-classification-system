#include "servo.h"

// Initialize servo pins
void servo_init(void) {
    // Set Servo pins as output
    DDRD |= (1 << SERVO_PIN);
    DDRD |= (1 << SERVO2_PIN);
    
    // Make sure MG995 Full Metal servo is in closed position at start
    servo2_close_trash();
}

// Function to send pulse to SG90 servo to the right (wider angle)
void servo_right(void) {
    for (int i = 0; i < 50; i++) {
        PORTD |= (1 << SERVO_PIN);    // Servo pulse on
        _delay_us(2300);              // 2.3ms pulse width (further right position)
        PORTD &= ~(1 << SERVO_PIN);   // Servo pulse off
        _delay_ms(17.7);              // Complete 20ms cycle
    }
}

// Function to send pulse to SG90 servo to the left (wider angle)
void servo_left(void) {
    for (int i = 0; i < 50; i++) {
        PORTD |= (1 << SERVO_PIN);    // Servo pulse on
        _delay_us(700);               // 0.7ms pulse width (further left position)
        PORTD &= ~(1 << SERVO_PIN);   // Servo pulse off
        _delay_ms(19.3);              // Complete 20ms cycle
    }
}

// Function to send pulse to SG90 servo to the center
void servo_center(void) {
    for (int i = 0; i < 50; i++) {
        PORTD |= (1 << SERVO_PIN);    // Servo pulse on
        _delay_us(1500);              // 1.5ms pulse width (center position)
        PORTD &= ~(1 << SERVO_PIN);   // Servo pulse off
        _delay_ms(18.5);              // Complete 20ms cycle
    }
}

// Function to stop the MG995 Full Metal continuous rotation servo
void servo2_stop(void) {
    for (int i = 0; i < 50; i++) {
        PORTD |= (1 << SERVO2_PIN);
        _delay_us(1500);           // 1.5ms pulse width (stop position for continuous rotation)
        PORTD &= ~(1 << SERVO2_PIN);
        _delay_ms(18.5);           // Complete 20ms cycle
    }
}

// Function to rotate MG995 Full Metal servo clockwise (to open the trash bin)
void servo2_open_trash(void) {
    // Rotate clockwise at moderate speed for a set time
    uint16_t start_time = 0;
    while (start_time < OPEN_TIME_MS) {
        PORTD |= (1 << SERVO2_PIN);
        _delay_us(1700);           // >1.5ms pulse width (clockwise rotation)
        PORTD &= ~(1 << SERVO2_PIN);
        _delay_ms(18.3);           // Complete 20ms cycle
        start_time += 20;          // Increment by cycle time
    }
    
    // Stop the servo after reaching the desired position
    servo2_stop();
}

// Function to rotate MG995 Full Metal servo counter-clockwise (to close the trash bin)
void servo2_close_trash(void) {
    // Rotate counter-clockwise at moderate speed for a set time
    uint16_t start_time = 0;
    while (start_time < CLOSE_TIME_MS) {
        PORTD |= (1 << SERVO2_PIN);
        _delay_us(1300);           // <1.5ms pulse width (counter-clockwise rotation)
        PORTD &= ~(1 << SERVO2_PIN);
        _delay_ms(18.7);           // Complete 20ms cycle
        start_time += 20;          // Increment by cycle time
    }
    
    // Stop the servo after reaching the desired position
    servo2_stop();
}