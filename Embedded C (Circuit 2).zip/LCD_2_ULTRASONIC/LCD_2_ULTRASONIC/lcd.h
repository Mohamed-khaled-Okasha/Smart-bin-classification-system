/*
 * lcd.h
 *
 * Created: 5/21/2025
 * Author: Based on original by huawei
 */ 
#ifndef LCD_H_
#define LCD_H_

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

// ========== LCD Definitions ==========
#define LCD_RS      PD0
#define LCD_EN      PD1
#define LCD_D4      PD2
#define LCD_D5      PD3
#define LCD_D6      PD4
#define LCD_D7      PD5
#define LCD_PORT    PORTD
#define LCD_DDR     DDRD
#define LCD_PIN     PIND

// Comandos LCD para modo 4-bit
#define LCD_CLEAR           0x01
#define LCD_HOME            0x02
#define LCD_ENTRY_MODE      0x06  // Incremento cursor, sin desplazamiento
#define LCD_DISPLAY_ON      0x0C  // Display on, cursor off, parpadeo off
#define LCD_FUNCTION_4BIT   0x28  // 4-bit, 2 líneas, 5x8 dots
#define LCD_FUNCTION_RESET  0x30  // Secuencia de reset
#define LCD_SET_CGRAM       0x40
#define LCD_SET_DDRAM       0x80

// ========== Prototipos de funciones LCD ==========
void lcd_init(void);
void lcd_send_command(uint8_t cmd);
void lcd_send_data(uint8_t data);
void lcd_send_byte(uint8_t byte);
void lcd_send_nibble(uint8_t nibble);
void lcd_clear(void);
void lcd_home(void);
void lcd_set_cursor(uint8_t row, uint8_t col);
void lcd_string(const char *str);
void lcd_create_char(uint8_t location, const uint8_t *charmap);

#endif /* LCD_H_ */