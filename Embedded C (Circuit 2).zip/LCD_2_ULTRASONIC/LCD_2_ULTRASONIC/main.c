/*
 * main.c
 *
 * Created: 5/21/2025 (updated from 4/30/2025)
 * Author: Based on original by huawei
 */ 

#include "main.h"

// ==================== FUNCIONES DE UTILIDAD ====================

// Inicializa todos los subsistemas
void system_init(void) {
    // Configura puertos no utilizados como salidas con bajo
    DDRB = 0xFF;
    PORTB = 0x00;
    DDRC = 0xFF;
    PORTC = 0x00;
    
    // Inicializa LCD
    lcd_init();
    
    // Inicializa ADC
    adc_init();
    
    // Inicializa sensores ultrasónicos
    ultrasonic_init();
    
    // Pequeño retraso para que todo se estabilice
    _delay_ms(100);
}

// Calcula el porcentaje de llenado en base a la distancia
uint8_t calculate_fill_percentage(uint16_t distance) {
    uint8_t fill_percentage;
    
    if (distance >= BIN_DEPTH_CM) {
        fill_percentage = 0; // Vacío
    } else if (distance <= MIN_DISTANCE_CM) {
        fill_percentage = 100; // Lleno
    } else {
        // Calcula porcentaje basado en la distancia
        fill_percentage = 100 - ((distance - MIN_DISTANCE_CM) * 100) / (BIN_DEPTH_CM - MIN_DISTANCE_CM);
    }
    
    return fill_percentage;
}

// Muestra el estado de los contenedores en la pantalla LCD
void display_bin_status(uint8_t fill1, uint8_t fill2, uint16_t dist1, uint16_t dist2) {
    char lcd_buffer[17]; // Buffer para 16 caracteres + null
    
    // Línea 1: Porcentajes de llenado
    lcd_set_cursor(0, 0);
    snprintf(lcd_buffer, sizeof(lcd_buffer), "B1:%3d%% B2:%3d%%", fill1, fill2);
    lcd_string(lcd_buffer);
    
    // Línea 2: Distancias
    lcd_set_cursor(1, 0);
    snprintf(lcd_buffer, sizeof(lcd_buffer), "D1:%2dcm D2:%2dcm", dist1, dist2);
    lcd_string(lcd_buffer);
}

// Maneja errores mostrando código en LCD
void handle_error(uint8_t error_code) {
    char error_msg[17]; // Buffer para mensaje de error
    
    lcd_clear();
    lcd_set_cursor(0, 0);
    lcd_string("ERROR");
    
    lcd_set_cursor(1, 0);
    snprintf(error_msg, sizeof(error_msg), "Code: %d", error_code);
    lcd_string(error_msg);
    
    _delay_ms(2000); // Muestra el error por 2 segundos
}

// ==================== FUNCIÓN PRINCIPAL ====================

int main(void) {
    uint16_t distance1 = 0, distance2 = 0, distance3 = 0;
    uint8_t fill1_percentage = 0, fill2_percentage = 0;
    uint8_t error_status = ERR_NONE;
    
    // Inicializa todos los subsistemas
    system_init();
    
    // Muestra mensaje de bienvenida
    lcd_clear();
    lcd_string("Smart Trash Bin");
    lcd_set_cursor(1, 0);
    lcd_string("Initializing...");
    _delay_ms(1000);
    
    // Bucle principal
    while (1) {
        // Mide distancia con sensor 1 (nivel de basura 1)
        distance1 = measure_distance(US1_TRIG_PIN_NUM, US1_ECHO_PIN_NUM);
        _delay_ms(20); // Pequeño retraso entre mediciones (aumentado)
        
        // Mide distancia con sensor 2 (nivel de basura 2)
        distance2 = measure_distance(US2_TRIG_PIN_NUM, US2_ECHO_PIN_NUM);
        _delay_ms(20); // Pequeño retraso entre mediciones
        
        // Mide distancia con sensor 3 (detección de persona)
        distance3 = measure_distance(US3_TRIG_PIN_NUM, US3_ECHO_PIN_NUM);
        
        // Calcula porcentajes de llenado
        fill1_percentage = calculate_fill_percentage(distance1);
        fill2_percentage = calculate_fill_percentage(distance2);
        
        // Muestra información en LCD
        lcd_clear();
        display_bin_status(fill1_percentage, fill2_percentage, distance1, distance2);
        
        // Indicador de detección de persona en LCD
        if (distance3 < PERSON_DISTANCE_CM) {
            lcd_set_cursor(0, 14);
            lcd_string("P!");  // Indicador de persona detectada
        }
        
        // Espera antes de la siguiente medición
        _delay_ms(MEASUREMENT_DELAY);
    }
    
    return 0; // Nunca se alcanza
}