/*
 * adc.c
 *
 * Created: 5/21/2025
 * Author: Based on original by huawei
 */ 

#include "adc.h"
#include <util/delay.h>

// ==================== FUNCIONES ADC ====================

// Inicializa el ADC
void adc_init(void) {
    // Referencia de voltaje: AVCC con capacitor externo en AREF
    ADMUX = (1 << REFS0);
    
    // Habilita ADC, prescaler 128 (frecuencia ADC = 125kHz a 16MHz)
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
    
    // Primera conversión dummy (para calibrar)
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1 << ADSC));
}

// Lee un canal ADC
uint16_t adc_read(uint8_t channel) {
    // Validar canal
    if (channel > 7) channel = 7;
    
    // Selecciona canal (0-7)
    ADMUX = (ADMUX & 0xF8) | (channel & 0x07);
    
    // Pequeño retraso para estabilizar el multiplexor
    _delay_us(10);
    
    // Inicia la conversión
    ADCSRA |= (1 << ADSC);
    
    // Espera a que termine la conversión
    while (ADCSRA & (1 << ADSC));
    
    // Devuelve el resultado
    return ADC;
}