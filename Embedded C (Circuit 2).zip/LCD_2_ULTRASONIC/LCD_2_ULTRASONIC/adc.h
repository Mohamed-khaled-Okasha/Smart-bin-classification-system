/*
 * adc.h
 *
 * Created: 5/21/2025
 * Author: Based on original by huawei
 */ 
#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

// ========== ADC Channels ==========
#define POT1_CHANNEL 1
#define POT2_CHANNEL 0  // (Unused)

// ========== Prototipos de funciones ADC ==========
void adc_init(void);
uint16_t adc_read(uint8_t channel);

#endif /* ADC_H_ */