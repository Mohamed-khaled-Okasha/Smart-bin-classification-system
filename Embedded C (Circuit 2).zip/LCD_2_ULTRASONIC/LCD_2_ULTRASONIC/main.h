/*
 * main.h
 *
 * Created: 5/21/2025 (updated from 4/30/2025)
 * Author: Based on original by huawei
 */ 
#ifndef MAIN_H_
#define MAIN_H_

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Incluir archivos de cabecera de los módulos
#include "lcd.h"
#include "adc.h"
#include "ultrasonic.h"

// Definición de frecuencia del microcontrolador
#define F_CPU 16000000UL  // 16 MHz

// Código de errores
enum ErrorCodes {
    ERR_NONE = 0,
    ERR_US_TIMEOUT = 1,
    ERR_LCD_INIT = 2,
    ERR_ADC_READ = 3
};

// ========== Funciones de utilidad ==========
void system_init(void);
uint8_t calculate_fill_percentage(uint16_t distance);
void display_bin_status(uint8_t fill1, uint8_t fill2, uint16_t dist1, uint16_t dist2);
void handle_error(uint8_t error_code);

#endif /* MAIN_H_ */