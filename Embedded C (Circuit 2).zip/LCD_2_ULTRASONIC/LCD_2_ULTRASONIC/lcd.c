/*
 * lcd.c
 *
 * Created: 5/21/2025
 * Author: Based on original by huawei
 */ 

#include "lcd.h"
#include <util/delay.h>

// ==================== FUNCIONES LCD (MODO 4-BIT) ====================

// Envía un nibble (4 bits) al LCD
void lcd_send_nibble(uint8_t nibble) {
    // Conservar los bits que no forman parte de los datos
    uint8_t port_state = LCD_PORT & ~((1 << LCD_D4) | (1 << LCD_D5) | (1 << LCD_D6) | (1 << LCD_D7));
    
    // Establece los 4 bits de datos de una manera más eficiente
    LCD_PORT = port_state |
              ((nibble & 0x01) << LCD_D4) |
              ((nibble & 0x02) << (LCD_D5-1)) |
              ((nibble & 0x04) << (LCD_D6-2)) |
              ((nibble & 0x08) << (LCD_D7-3));
    
    // Pulso de habilitación
    LCD_PORT |= (1 << LCD_EN);
    _delay_us(2);  // Enable pulse debe ser >450ns (ajustado para 16MHz)
    LCD_PORT &= ~(1 << LCD_EN);
    _delay_us(100); // Esperar a que el LCD procese (aumentado para mayor seguridad)
}

// Envía un byte completo al LCD (dividido en dos nibbles)
void lcd_send_byte(uint8_t byte) {
    // Envía nibble alto (4 bits superiores)
    lcd_send_nibble(byte >> 4);
    // Envía nibble bajo (4 bits inferiores)
    lcd_send_nibble(byte & 0x0F);
}

// Envía un comando al LCD
void lcd_send_command(uint8_t cmd) {
    LCD_PORT &= ~(1 << LCD_RS); // RS = 0 para comandos
    lcd_send_byte(cmd);
    // Esperar a que el comando se ejecute
    if (cmd == LCD_CLEAR || cmd == LCD_HOME)
        _delay_ms(5); // Aumentado para mayor seguridad
    else
        _delay_us(100); // Aumentado para mayor seguridad
}

// Envía datos al LCD
void lcd_send_data(uint8_t data) {
    LCD_PORT |= (1 << LCD_RS); // RS = 1 para datos
    lcd_send_byte(data);
    _delay_us(100); // Aumentado para mayor seguridad
}

// Inicializa el LCD en modo 4-bit
void lcd_init(void) {
    // Configura pines como salidas
    LCD_DDR |= (1 << LCD_RS) | (1 << LCD_EN) |
              (1 << LCD_D4) | (1 << LCD_D5) |
              (1 << LCD_D6) | (1 << LCD_D7);
    
    // Inicialmente todos los pines en bajo
    LCD_PORT &= ~((1 << LCD_RS) | (1 << LCD_EN) |
                 (1 << LCD_D4) | (1 << LCD_D5) |
                 (1 << LCD_D6) | (1 << LCD_D7));
    
    // Esperar más de 40ms después de encendido
    _delay_ms(100); // Aumentado para mayor seguridad
    
    // Inicialización especial para modo 4-bit
    // Primero aseguramos que RS=0 (modo comando)
    LCD_PORT &= ~(1 << LCD_RS);
    LCD_PORT &= ~(1 << LCD_EN);
    
    // Secuencia de inicialización según datasheet
    // Envía 0x3 tres veces para asegurar modo 8-bit inicialmente
    lcd_send_nibble(0x03);
    _delay_ms(5);
    lcd_send_nibble(0x03);
    _delay_ms(5); // Aumentado para mayor seguridad
    lcd_send_nibble(0x03);
    _delay_ms(5); // Aumentado para mayor seguridad
    
    // Cambiar a modo 4-bit
    lcd_send_nibble(0x02);
    _delay_ms(5); // Aumentado para mayor seguridad
    
    // Ahora ya estamos en modo 4-bit y podemos usar lcd_send_command()
    lcd_send_command(LCD_FUNCTION_4BIT); // Configurar: 4-bit, 2 líneas, 5x8 dots
    _delay_ms(1);
    lcd_send_command(LCD_DISPLAY_ON);    // Display on, cursor off, parpadeo off
    _delay_ms(1);
    lcd_send_command(LCD_CLEAR);         // Borrar display
    _delay_ms(5);
    lcd_send_command(LCD_ENTRY_MODE);    // Incremento cursor, sin desplazamiento
    _delay_ms(1);
}

// Borra la pantalla LCD
void lcd_clear(void) {
    lcd_send_command(LCD_CLEAR);
    _delay_ms(5); // Asegurar que la pantalla tenga tiempo de limpiarse
}

// Establece cursor en inicio
void lcd_home(void) {
    lcd_send_command(LCD_HOME);
    _delay_ms(5); // Asegurar que el cursor tenga tiempo de moverse
}

// Establece la posición del cursor
void lcd_set_cursor(uint8_t row, uint8_t col) {
    uint8_t address;
    
    // Validar límites
    if (row > 1) row = 1;
    if (col > 15) col = 15;
    
    if (row == 0) {
        address = 0x00 + col; // Primera línea comienza en 0x00
    } else {
        address = 0x40 + col; // Segunda línea comienza en 0x40
    }
    
    lcd_send_command(LCD_SET_DDRAM | address);
    _delay_us(100); // Tiempo para que se mueva el cursor
}

// Envía una cadena de texto al LCD
void lcd_string(const char *str) {
    uint8_t i = 0;
    
    // Proteger contra cadenas demasiado largas o nulas
    if (!str) return;
    
    while (str[i] != '\0' && i < 16) { // Límite de 16 caracteres por línea
        lcd_send_data(str[i]);
        i++;
    }
}

// Crea un carácter personalizado
void lcd_create_char(uint8_t location, const uint8_t *charmap) {
    uint8_t i;
    
    // Validar puntero
    if (!charmap) return;
    
    // Máximo 8 caracteres personalizados (0-7)
    location &= 0x07;
    
    lcd_send_command(LCD_SET_CGRAM | (location << 3));
    
    for (i = 0; i < 8; i++) {
        lcd_send_data(charmap[i]);
    }
    
    // Volver a DDRAM
    lcd_send_command(LCD_SET_DDRAM);
}