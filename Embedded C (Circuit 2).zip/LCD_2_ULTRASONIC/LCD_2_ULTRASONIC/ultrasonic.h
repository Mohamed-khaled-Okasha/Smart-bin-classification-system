/*
 * ultrasonic.h
 *
 * Created: 5/21/2025
 * Author: Based on original by huawei
 */ 
#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <avr/interrupt.h>

// ========== Ultrasonic Sensor ==========
#define US_DDR      DDRA
#define US_PORT     PORTA
#define US_PIN      PINA
#define US1_TRIG_PIN PA3    // PIN_PA3
#define US1_ECHO_PIN PA0    // PIN_PA0
#define US2_TRIG_PIN PA4    // PIN_PA4
#define US2_ECHO_PIN PA2    // PIN_PA2
#define US3_TRIG_PIN PA5    // PIN_PA5 - Nuevo sensor para detectar personas
#define US3_ECHO_PIN PA6    // PIN_PA6 - Nuevo sensor para detectar personas

// Definición de pines con números para facilitar su uso en funciones
#define US1_TRIG_PIN_NUM    3
#define US1_ECHO_PIN_NUM    0
#define US2_TRIG_PIN_NUM    4
#define US2_ECHO_PIN_NUM    2
#define US3_TRIG_PIN_NUM    5
#define US3_ECHO_PIN_NUM    6

// ========== Parámetros de la aplicación ==========
#define BIN_DEPTH_CM        50    // Profundidad del contenedor de basura
#define MIN_DISTANCE_CM     5     // Distancia mínima para considerar 100% lleno
#define PERSON_DISTANCE_CM  30    // Distancia para detectar persona
#define MAX_SENSOR_TIMEOUT  50000 // Timeout para prevenir bloqueos (aumentado)
#define ULTRASONIC_TIMEOUT  20    // Timeout máximo para medición (ms) (aumentado)

// ========== Prototipos de funciones de ultrasonido ==========
void ultrasonic_init(void);
uint16_t measure_distance(uint8_t trig_pin, uint8_t echo_pin);
void trig_pulse(uint8_t trig_pin);

// Declaración externa de variable global del contador de desbordamiento
extern volatile uint16_t timer_overflow_count;

#endif /* ULTRASONIC_H_ */