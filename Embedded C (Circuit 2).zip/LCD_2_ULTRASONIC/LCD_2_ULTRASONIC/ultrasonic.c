/*
 * ultrasonic.c
 *
 * Created: 5/21/2025
 * Author: Based on original by huawei
 */ 

#include "ultrasonic.h"
#include <util/delay.h>
#include <avr/interrupt.h>

// Variable global para contar desbordamientos del temporizador
volatile uint16_t timer_overflow_count = 0;

// Manejador de interrupciones para desbordamiento del Timer1
ISR(TIMER1_OVF_vect) {
    timer_overflow_count++;
}

// ==================== FUNCIONES ULTRASÓNICAS ====================

// Inicializa los sensores ultrasónicos
void ultrasonic_init(void) {
    // Configura pines TRIG como salidas
    US_DDR |= (1 << US1_TRIG_PIN_NUM) | (1 << US2_TRIG_PIN_NUM) | (1 << US3_TRIG_PIN_NUM);
    
    // Configura pines ECHO como entradas
    US_DDR &= ~((1 << US1_ECHO_PIN_NUM) | (1 << US2_ECHO_PIN_NUM) | (1 << US3_ECHO_PIN_NUM));
    
    // Inicialmente pins TRIG en bajo
    US_PORT &= ~((1 << US1_TRIG_PIN_NUM) | (1 << US2_TRIG_PIN_NUM) | (1 << US3_TRIG_PIN_NUM));
    
    // Configura Timer1 para medición de tiempo
    TCCR1A = 0; // Modo normal
    TIMSK |= (1 << TOIE1); // Habilita interrupción por desbordamiento
    
    // Habilita interrupciones globales
    sei();
}

// Genera un pulso en el pin TRIG
void trig_pulse(uint8_t trig_pin) {
    US_PORT &= ~(1 << trig_pin); // Asegura que el pin esté en bajo
    _delay_us(4);
    US_PORT |= (1 << trig_pin);  // Establece el pin en alto
    _delay_us(12);               // Pulso de 12µs (garantiza 10µs mínimos)
    US_PORT &= ~(1 << trig_pin); // Regresa el pin a bajo
}

// Mide la distancia utilizando un sensor ultrasónico
uint16_t measure_distance(uint8_t trig_pin, uint8_t echo_pin) {
    uint32_t pulse_duration, distance_cm;
    uint16_t timeout_counter = 0;
    
    // Deshabilita interrupciones durante la medición crítica
    cli();
    
    // Genera pulso de disparo
    trig_pulse(trig_pin);
    
    // Reinicia el contador
    TCNT1 = 0;
    timer_overflow_count = 0;
    TCCR1B = (1 << CS10); // Sin prescaler
    
    // Espera hasta que el pin ECHO se ponga en alto o timeout
    while (!(US_PIN & (1 << echo_pin))) {
        if (++timeout_counter > MAX_SENSOR_TIMEOUT) {
            TCCR1B = 0; // Detiene el temporizador
            sei(); // Rehabilita interrupciones
            return BIN_DEPTH_CM; // Retorna valor máximo en caso de error
        }
    }
    
    // Reinicia contador para medir duración del pulso
    TCNT1 = 0;
    timer_overflow_count = 0;
    timeout_counter = 0;
    
    // Espera hasta que el pin ECHO se ponga en bajo o timeout
    while (US_PIN & (1 << echo_pin)) {
        if (timer_overflow_count > 5 || ++timeout_counter > MAX_SENSOR_TIMEOUT) {
            TCCR1B = 0; // Detiene el temporizador
            sei(); // Rehabilita interrupciones
            return BIN_DEPTH_CM; // Retorna valor máximo en caso de error
        }
    }
    
    // Detiene el temporizador
    TCCR1B = 0;
    
    // Rehabilita interrupciones
    sei();
    
    // Calcula la duración del pulso
    pulse_duration = (timer_overflow_count * 65536UL) + TCNT1;
    
    // Calcula la distancia (Velocidad del sonido = 343 m/s = 34300 cm/s)
    // Distancia = (Tiempo × Velocidad) ÷ 2
    // Para F_CPU = 16MHz, cada ciclo es 0.0625 µs
    distance_cm = pulse_duration * 0.01075; // Valor calibrado para 16MHz
    
    // Limita la distancia al rango válido
    if (distance_cm > BIN_DEPTH_CM) {
        distance_cm = BIN_DEPTH_CM;
    }
    
    return (uint16_t)distance_cm;
}